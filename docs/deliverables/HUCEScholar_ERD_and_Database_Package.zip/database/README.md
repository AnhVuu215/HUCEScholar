# HUCEScholar Database Design

Thiết kế dữ liệu ngày 10/10/2026, dựa trên proposal, use case và quy tắc nghiệp vụ phiên bản 1.1.

- `HUCEScholar_schema_postgresql.sql`: schema SQL tham chiếu, tạo namespace `hucescholar` trong một database trống. Không phải migration cho database đang có dữ liệu.
- `HUCEScholar_ERD_logical.mmd`: ERD tổng quan để đưa vào báo cáo.
- `HUCEScholar_ERD_physical.mmd`: toàn bộ bảng và quan hệ khóa ngoại.
- `HUCEScholar_Data_Dictionary.md`: từ điển đầy đủ các trường, nullability, ràng buộc và quan hệ.
- `diagrams/`: hình ERD có thể chèn vào báo cáo; các góc nhìn tập trung vào quan hệ chính. Mermaid vật lý và SQL là nguồn đầy đủ cho mọi khóa ngoại, bao gồm người thực hiện lịch sử.

SQL chọn PostgreSQL làm phương án tham chiếu. Đây chưa phải quyết định toàn bộ stack ứng dụng. Thiết kế chọn một role chính mỗi tài khoản và một phiên bản đang biên tập mỗi tài liệu để giữ MVP đơn giản; các lựa chọn này được ghi riêng với chính sách nghiệp vụ đã chốt.

Chỉ chạy schema trên database trống dành riêng cho phát triển hoặc kiểm tra. Script không xóa hoặc ghi đè schema cũ; chạy lại trên cùng database sẽ báo đã tồn tại.

```powershell
# Thay placeholder bằng database trống đã tạo và tài khoản được cấp quyền phù hợp.
psql -X -v ON_ERROR_STOP=1 -h localhost -p 5432 -U <database_user> -d <empty_database> -f .\docs\database\HUCEScholar_schema_postgresql.sql
```

Đọc cùng tài liệu Word trong `docs/deliverables/HUCEScholar_ERD_and_Data_Design.docx`. Script sinh các đầu ra là `docs/tools/build_data_design.py`; mô hình gốc ở `docs/tools/hucescholar_data_model.py`. Không chỉnh SQL/diagram riêng rồi bỏ quên mô hình gốc.

Phân quyền người dùng, xác minh role/phân công, số trang ghi chú, quyền nguồn, thứ tự trạng thái, cập nhật revision, cuối cùng còn một admin và giao dịch bàn giao vẫn cần backend triển khai. Database chỉ cưỡng chế những phần được ghi rõ trong tài liệu; không suy ra có RLS hoặc API an toàn chỉ từ các FK.

Kết quả kiểm tra nằm trong `docs/_qa/data_design_validation.json`. Database kiểm tra độc lập với database triển khai sau này. Dữ liệu fixture dùng giao dịch rollback; không phải dữ liệu mẫu tồn tại lâu dài hay bằng chứng đã có nội dung trường.

Đã áp dụng thành công schema vào PostgreSQL 18.3 tạm: 23 bảng, 47 khóa ngoại và 37 ca kiểm tra đạt. Sau rollback không còn tài khoản fixture; server tạm đã dừng. Gói ZIP có bản kết quả tại `validation/Database_Validation.json`.

Mermaid vật lý dùng đường liền khi FK tham gia PK của bảng con, đường đứt cho quan hệ không định danh; số lượng tối thiểu/tối đa theo FK và unique, chưa bao gồm mọi điều kiện nghiệp vụ. Quy ước: [Mermaid Entity Relationship Diagrams](https://mermaid.js.org/syntax/entityRelationshipDiagram.html). File `.mmd` là mã nguồn chỉnh sửa; các hình PNG kèm theo là sơ đồ đã dựng riêng cho tài liệu Word.
